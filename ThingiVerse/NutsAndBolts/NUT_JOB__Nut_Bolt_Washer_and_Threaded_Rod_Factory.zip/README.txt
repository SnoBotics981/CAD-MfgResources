                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:193647
NUT JOB | Nut, Bolt, Washer and Threaded Rod Factory by mike_mattala is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Generate your own nuts, bolts, washers and threaded rod by simply typing the required parameters into customizer.  Great for replacing metal equivalents in many applications such as the ROLLER RING |  Universal Filament Spool Holder http://www.thingiverse.com/thing:176442.  
Includes options to generate WingNuts for easy hand tightening and removal.  Now includes socket cap, socket button and socket countersunk head types with support for socket, phillips and slot drives.  
You can also join threaded rod to form unlimited lengths by creating a custom extended joiner nut.  
Uses the PolyScrewThread library from http://www.thingiverse.com/thing:8796

NEW Updated version 6/3/2016: added extended options to control number of facets on nuts, square sockets (or any number of facets) and socket depth control.

NEW Updated version 1/1/2017: modified library code to remove dependence on deprecated 'assign' statement.