                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1412606
Test Lead Holder -basic and varied width by Crayok is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Basic Test lead holder for cables up to 6.35mm (RG-6 with connector).  You can fit your meter, generator and power leads on this hanger.  Holes for wall mount or if not a lot of weight some two sided tape may work.

All the STL files have been fixed (disconnected parts seen in some slicers)  Cura was fine with the original STL's.

There are supports about 2/3 the finger length to handle higher weights for lots of cables.  Maybe over built.  The varied width hanger is a lighter build.  

I have an updated SCAD file (1.1) up to add or take slots away, trim sides plus other configurable pieces, enjoy.

Let me know what you think.
David

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker Original
Rafts: No
Supports: No
Resolution: 0.1 - 0.2mm
Infill: 20%

Notes: 
The two prebuilt hangers pretty much fills the Ultimaker bed.  There is nothing special required.  You are printing this upside down for a flat top.